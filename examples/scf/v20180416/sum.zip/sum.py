def sum(a, b):
    return a + b
