# coding: utf-8
import logging
import sum

logger = logging.getLogger()


def main_handler(event, content):
    logger.debug("sum is running")
    key1 = event.get("key1", 0)
    key2 = event.get("key2", 0)
    return sum.sum(key1, key2)


if __name__ == "__main__":
    print main_handler({"key1": 1, "key2": 2}, {})
